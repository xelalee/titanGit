package com.titan.base.account.exception;

import com.titan.base.app.exception.ModelException;

public class AccountActivateException  extends ModelException{
    public AccountActivateException() {
        super("AccountActivateException");
    }
}
