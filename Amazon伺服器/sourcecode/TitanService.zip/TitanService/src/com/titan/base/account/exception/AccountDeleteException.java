package com.titan.base.account.exception;

import com.titan.base.app.exception.ModelException;

public class AccountDeleteException extends ModelException{
    public AccountDeleteException() {
        super("AccountDeleteException");
    }
    
}
