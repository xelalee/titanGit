package com.titan.base.account.exception;

import com.titan.base.app.exception.ModelException;


public class AccountInsertException extends ModelException{
	public AccountInsertException(){
		super("AccountInsertException");
	}
}
