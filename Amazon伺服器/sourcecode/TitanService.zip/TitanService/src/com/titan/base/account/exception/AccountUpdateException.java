package com.titan.base.account.exception;

import com.titan.base.app.exception.ModelException;


public class AccountUpdateException extends ModelException{
	public AccountUpdateException(){
		super("AccountUpdateException");
	}
}
