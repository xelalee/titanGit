package com.titan.base.account.exception;

import com.titan.base.app.exception.ModelException;

public class ValidationCodeException extends ModelException{
	public ValidationCodeException(){
		super("ValidationCodeException");
	}
	
}
