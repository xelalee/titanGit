package com.titan.base.app.exception;

public class LKReusedException extends Exception {
    public LKReusedException() {
    }

    public LKReusedException(String msg) {
        super(msg);
    }
}