package com.titan.base.controller;

public class ActionName {
	//content filter register 
	public final static String CONTENT_FILTER_REGISTER = "content_filter_register";
		
	public final static String login = "login";

	public final static String logout = "logout";
	
	public final static String admin = "admin";
}
