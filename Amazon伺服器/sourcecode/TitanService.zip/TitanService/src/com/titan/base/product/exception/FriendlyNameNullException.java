package com.titan.base.product.exception;

import com.titan.base.app.exception.ModelException;


public class FriendlyNameNullException extends ModelException{
	public FriendlyNameNullException(){
		super("FriendlyNameNullException");
	}
}
