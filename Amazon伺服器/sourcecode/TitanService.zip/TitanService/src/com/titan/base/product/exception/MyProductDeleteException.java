package com.titan.base.product.exception;

import com.titan.base.app.exception.ModelException;


public class MyProductDeleteException extends ModelException{
	public MyProductDeleteException(){
		super("MyProductInsertException");
	}

}
