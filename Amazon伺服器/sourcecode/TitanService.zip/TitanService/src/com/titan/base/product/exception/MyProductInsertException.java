package com.titan.base.product.exception;

import com.titan.base.app.exception.ModelException;


public class MyProductInsertException extends ModelException{
	public MyProductInsertException(){
		super("MyProductInsertException");
	}

}
