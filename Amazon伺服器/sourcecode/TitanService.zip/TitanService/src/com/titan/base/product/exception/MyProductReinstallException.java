package com.titan.base.product.exception;

import com.titan.base.app.exception.ModelException;


public class MyProductReinstallException extends ModelException{
	public MyProductReinstallException(){
		super("MyProductReinstallException");
	}
}
