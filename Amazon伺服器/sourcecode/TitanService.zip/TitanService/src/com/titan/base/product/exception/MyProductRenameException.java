package com.titan.base.product.exception;

import com.titan.base.app.exception.ModelException;


public class MyProductRenameException extends ModelException{
	public MyProductRenameException(){
		super("MyProductRenameException");
	}
}
