package com.titan.base.product.exception;

import com.titan.base.app.exception.ModelException;


public class MyProductTransferException extends ModelException{
	public MyProductTransferException(){
		super("MyProductTransferException");
	}
}
