package com.titan.base.product.exception;

import com.titan.base.app.exception.ModelException;


public class MyProductUpdateException extends ModelException{
	public MyProductUpdateException(){
		super("MyProductInsertException");
	}

}
