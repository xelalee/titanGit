package com.titan.base.product.exception;

import com.titan.base.app.exception.ModelException;


public class ReinstallToDeviceWithStandardServiceException extends ModelException{
	public ReinstallToDeviceWithStandardServiceException(){
		super("ReinstallToDeviceWithStandardServiceException");
	}
}
