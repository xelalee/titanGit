package com.titan.base.product.exception;

import com.titan.base.app.exception.ModelException;


public class ReinstallToSameDeviceException extends ModelException{
	public ReinstallToSameDeviceException(){
		super("ReinstallToSameDeviceException");
	}
}
