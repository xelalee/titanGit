package com.titan.base.product.exception;

import com.titan.base.app.exception.ModelException;


public class SerialNumberNullException extends ModelException{
	public SerialNumberNullException(){
		super("SerialNumberNullException");
	}
}
