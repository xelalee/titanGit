package com.titan.base.product.exception;

import com.titan.base.app.exception.ModelException;


public class SerialNumberUsedException extends ModelException{
	public SerialNumberUsedException(){
		super("SerialNumberUsedException");
	}
}
