package com.titan.base.product.exception;

import com.titan.base.app.exception.ModelException;


public class TransferToSelfException extends ModelException{
	public TransferToSelfException(){
		super("TransferToSelfException");
	}

}
