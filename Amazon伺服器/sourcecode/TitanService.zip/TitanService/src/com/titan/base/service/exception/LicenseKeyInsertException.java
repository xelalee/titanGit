package com.titan.base.service.exception;

import com.titan.base.app.exception.ModelException;


public class LicenseKeyInsertException extends ModelException{
	public LicenseKeyInsertException(){
		super("LicenseKeyInsertException");
	}
}
