package com.titan.base.service.exception;

import com.titan.base.app.exception.ModelException;


public class LicenseKeyNotMatchException extends ModelException{
	public LicenseKeyNotMatchException(){
		super("LicenseKeyNotMatchException");
	}
}
