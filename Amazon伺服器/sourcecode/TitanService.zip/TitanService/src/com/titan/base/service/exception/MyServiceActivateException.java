package com.titan.base.service.exception;

import com.titan.base.app.exception.ModelException;


public class MyServiceActivateException extends ModelException{
	public MyServiceActivateException(){
		super("MyServiceActivateException");
	}
}
