package com.titan.base.service.exception;

import com.titan.base.app.exception.ModelException;


public class MyServiceInsertException extends ModelException{
	public MyServiceInsertException(){
		super("MyServiceInsertException");
	}
}
