package com.titan.base.service.exception;

import com.titan.base.app.exception.ModelException;


public class MyServiceUpdateException extends ModelException{
	public MyServiceUpdateException(){
		super("MyServiceUpdateException");
	}
}
