package com.titan.base.service.exception;

import com.titan.base.app.exception.ModelException;


public class MyServiceUpgradeException extends ModelException{
	public MyServiceUpgradeException(){
		super("MyServiceUpgradeException");
	}
}
