package com.titan.base.service.exception;

import com.titan.base.app.exception.ModelException;

public class ReturnRegiIdToDeviceException extends ModelException {
	public ReturnRegiIdToDeviceException(){
		super("ReturnRegiIdToDeviceException");
	}

}
