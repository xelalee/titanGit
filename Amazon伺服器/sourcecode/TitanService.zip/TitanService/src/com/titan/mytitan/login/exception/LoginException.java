package com.titan.mytitan.login.exception;

import com.titan.base.app.exception.ModelException;

public class LoginException extends ModelException{
    public LoginException() {
        super("LoginException");
    }
}
