package com.titan.register.controller;

public class ActionName {
	public final static String ACCOUNT_CHECK    = "accountCheck";
	public final static String PRODUCT_REGISTER = "productRegister";	
	public final static String SERVICE_TRIAL    = "serviceTrial";
	public final static String SERVICE_UPGRADE  = "serviceUpgrade";
	public final static String SERVICE_REFRESH  = "serviceRefresh";
}
