
deploy online site
1. update src/jets3t.properties
2. update conf/config.properties
2. update conf/s3.properties


prepare content home
1. create folder content_home
2. sudo chown tomcat7 <directory>
   sudo chgrp tomcat7 <directory>