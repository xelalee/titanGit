package com.titan.common;

public class Command {
	
	public static final String ACTION_NEW = "new";
	public static final String ACTION_EDIT = "edit";
	public static final String ACTION_DELETE = "delete";
	public static final String ACTION_CANCEL = "cancel";
	public static final String ACTION_SAVE = "save";
	public static final String ACTION_SUBMIT = "submit";

}
