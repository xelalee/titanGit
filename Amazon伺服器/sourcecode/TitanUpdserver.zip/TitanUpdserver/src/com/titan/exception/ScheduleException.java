package com.titan.exception;

public class ScheduleException extends Exception {
    public ScheduleException() {
        super();
    }

    public ScheduleException(String err) {
        super(err);
    }

}