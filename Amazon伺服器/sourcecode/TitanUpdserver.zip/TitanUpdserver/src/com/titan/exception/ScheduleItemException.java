
package com.titan.exception;

public class ScheduleItemException extends Exception {
    public ScheduleItemException() {
        super();
    }

    public ScheduleItemException(String err) {
        super(err);
    }


}