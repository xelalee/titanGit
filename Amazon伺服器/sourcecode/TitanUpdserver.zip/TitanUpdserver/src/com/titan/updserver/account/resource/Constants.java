package com.titan.updserver.account.resource;

public class Constants{
	
	public final static String SQLSTMT_KEY = "SQLSTMT_KEY";
	public final static String SQL_PARAM = "SQL_PARAM";
	public final static String SQL_CONDITION = "SQL_CONDITION";
	public final static String DATASOURCE = "TXDATASOURCE_UPDSERVER";
	public final static String DIRECTOTY = "DIRECTORY";
	public final static String GROUP = "GROUP";
}