
package com.titan.updserver.common.exception;

public class AddFileException extends Exception {
	public AddFileException() {
		super();
	}

	public AddFileException(String err) {
		super(err);
	}
}