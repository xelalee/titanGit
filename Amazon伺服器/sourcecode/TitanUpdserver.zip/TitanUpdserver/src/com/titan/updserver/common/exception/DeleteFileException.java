package com.titan.updserver.common.exception;

public class DeleteFileException extends Exception {
	public DeleteFileException() {
		super();
	}

	public DeleteFileException(String err) {
		super(err);
	}
}