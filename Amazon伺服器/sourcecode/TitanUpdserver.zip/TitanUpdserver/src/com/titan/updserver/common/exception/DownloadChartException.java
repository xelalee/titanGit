package com.titan.updserver.common.exception;

public class DownloadChartException extends Exception{
	public DownloadChartException() {
		super();
	}

	public DownloadChartException(String err) {
		super(err);
	}
}
