
package com.titan.updserver.common.exception;


public class FetchFileException extends Exception {
	public FetchFileException() {
		super();
	}

	public FetchFileException(String err) {
		super(err);
	}
}