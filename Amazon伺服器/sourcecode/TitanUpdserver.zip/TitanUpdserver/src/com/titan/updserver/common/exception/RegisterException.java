package com.titan.updserver.common.exception;


public class RegisterException extends Exception {
	public RegisterException() {
		super();
	}

	public RegisterException(String err) {
		super(err);
	}
}