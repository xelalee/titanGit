package com.titan.updserver.common.exception;

public class UpdateFileException extends Exception {

	public UpdateFileException() {
		super();
	}

	public UpdateFileException(String err) {
		super(err);
	}
}