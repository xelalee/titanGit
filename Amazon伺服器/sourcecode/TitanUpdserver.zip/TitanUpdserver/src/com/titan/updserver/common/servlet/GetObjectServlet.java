package com.titan.updserver.common.servlet;

import javax.servlet.http.HttpServlet;

public class GetObjectServlet extends HttpServlet {

}
