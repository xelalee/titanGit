package com.titan.updserver.signature;

import java.sql.SQLException;
import java.util.List;

import org.apache.log4j.Logger;

import com.titan.schedulejob.SignatureHandlerJob;

public class SyncServer {
	
	static Logger logger = Logger.getLogger(SyncServer.class);
	

}
