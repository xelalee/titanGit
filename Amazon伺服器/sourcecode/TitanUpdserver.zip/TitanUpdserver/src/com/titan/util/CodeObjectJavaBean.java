
package com.titan.util;


public class CodeObjectJavaBean {
    private String code="";
    private Object obj=null;
    
    public String getCode(){
        return this.code;
    }
    
    public Object getObj(){
        return this.obj;
    }
    
    public void setCode(String code){
        this.code=code;
    }
    
    public void setObj(Object obj){
        this.obj=obj;
    }

}
